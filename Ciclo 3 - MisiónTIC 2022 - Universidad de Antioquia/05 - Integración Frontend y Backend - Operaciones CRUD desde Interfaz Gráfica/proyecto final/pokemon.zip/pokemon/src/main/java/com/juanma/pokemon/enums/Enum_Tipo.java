package com.juanma.pokemon.enums;

import javax.persistence.Table;

@Table(name = "tipo")
public enum Enum_Tipo {
    fuego,
    agua,
    planta,
    electrico
}
